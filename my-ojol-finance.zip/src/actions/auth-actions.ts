// File: src/actions/auth-actions.ts
// Tujuan: Server Action untuk mendaftarkan akun pengguna (driver ojol) baru ke database.
// Menggunakan 'use server' agar seluruh proses enkripsi password (bcrypt) dan penulisan ke Prisma
// dieksekusi dengan aman di sisi server tanpa membocorkan kredensial database ke klien.

"use server";

import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";

// Tipe data respons standar untuk Server Action autentikasi
export interface AuthActionResponse {
  success: boolean;
  message: string;
}

/**
 * Fungsi Server Action untuk membuat akun pengguna baru (Register)
 * @param username - Nama pengguna unik milik driver
 * @param password - Kata sandi teks biasa yang akan di-hash dengan bcrypt
 */
export async function registerUserAction(
  username: string,
  password: string
): Promise<AuthActionResponse> {
  try {
    // 1. Bersihkan spasi berlebih dari input username
    const cleanUsername = username.trim();

    // 2. Validasi panjang karakter minimal untuk menjaga keamanan akun
    if (!cleanUsername || cleanUsername.length < 3) {
      return {
        success: false,
        message: "Username minimal harus terdiri dari 3 karakter.",
      };
    }

    if (!password || password.length < 4) {
      return {
        success: false,
        message: "Password minimal harus terdiri dari 4 karakter.",
      };
    }

    // 3. Periksa apakah username sudah pernah terdaftar di tabel User
    const existingUser = await prisma.user.findUnique({
      where: { username: cleanUsername },
    });

    if (existingUser) {
      return {
        success: false,
        message: "Username sudah digunakan. Silakan pilih username lain.",
      };
    }

    // 4. Enkripsi (Hash) password menggunakan bcrypt dengan salt rounds = 10
    const hashedPassword = await bcrypt.hash(password, 10);

    // 5. Simpan data pengguna baru ke dalam tabel User melalui Prisma ORM
    await prisma.user.create({
      data: {
        username: cleanUsername,
        password: hashedPassword,
      },
    });

    // 6. Kembalikan status sukses agar UI bisa langsung melanjutkan proses login otomatis
    return {
      success: true,
      message: "Akun berhasil dibuat! Sedang masuk ke aplikasi...",
    };
  } catch (error) {
    console.error("Gagal mendaftarkan pengguna baru:", error);
    return {
      success: false,
      message: "Terjadi kesalahan pada server saat mendaftarkan akun.",
    };
  }
}
