// File: src/actions/bill-actions.ts
// Tujuan: Mengelola seluruh proses CRUD (Create, Read, Update, Delete) serta aksi khusus "Bayar Tagihan"
// pada tabel `Bill` menggunakan Next.js Server Actions ('use server').

"use server";

import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

/**
 * Fungsi pembantu untuk memastikan user sudah login dan mengambil informasi user dari sesi aktif.
 */
async function requireAuthUser() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.id) {
    throw new Error("Akses ditolak: Silakan login terlebih dahulu.");
  }
  return session.user;
}

/**
 * 1. SERVER ACTION (READ): Mengambil seluruh daftar utang/cicilan milik user yang sedang login.
 * Diurutkan berdasarkan status belum lunas (isPaid: false) di bagian atas, lalu berdasarkan tanggal jatuh tempo terdekat.
 */
export async function getBillsAction() {
  const user = await requireAuthUser();

  const bills = await prisma.bill.findMany({
    where: {
      userId: user.id,
    },
    orderBy: [
      { isPaid: "asc" },  // Tagihan yang belum lunas (false) ditampilkan lebih dulu
      { dueDate: "asc" }, // Diurutkan dari jatuh tempo yang paling dekat
    ],
  });

  return bills;
}

/**
 * 2. SERVER ACTION (CREATE): Menambahkan data cicilan/tagihan baru ke tabel Bill
 * @param payload - Objek berisi nama cicilan (title), nominal (amount), dan tanggal jatuh tempo (dueDate)
 */
export async function createBillAction(payload: {
  title: string;
  amount: number;
  dueDate: string;
}) {
  try {
    const user = await requireAuthUser();

    // Validasi kelengkapan input dari form
    const cleanTitle = payload.title.trim();
    if (!cleanTitle) {
      return { success: false, message: "Nama cicilan/tagihan tidak boleh kosong." };
    }

    if (!payload.amount || payload.amount <= 0) {
      return { success: false, message: "Nominal cicilan harus lebih besar dari Rp 0." };
    }

    const parsedDueDate = new Date(payload.dueDate);
    if (isNaN(parsedDueDate.getTime())) {
      return { success: false, message: "Tanggal jatuh tempo tidak valid." };
    }

    // Simpan cicilan baru ke database menggunakan Prisma
    await prisma.bill.create({
      data: {
        userId: user.id,
        title: cleanTitle,
        amount: Math.round(payload.amount),
        dueDate: parsedDueDate,
        isPaid: false, // Default tagihan baru adalah belum lunas
      },
    });

    // Segarkan halaman /bills agar daftar tagihan terbaru langsung tampil di layar
    revalidatePath("/bills");

    return {
      success: true,
      message: "Tagihan/cicilan baru berhasil ditambahkan!",
    };
  } catch (error) {
    console.error("Gagal membuat tagihan baru:", error);
    return {
      success: false,
      message: "Terjadi kesalahan saat menyimpan tagihan baru.",
    };
  }
}

/**
 * 3. SERVER ACTION (UPDATE): Mengubah nama, nominal, atau tanggal jatuh tempo cicilan yang sudah ada
 * @param payload - Objek berisi id tagihan, title baru, amount baru, dan dueDate opsional
 */
export async function updateBillAction(payload: {
  id: string;
  title: string;
  amount: number;
  dueDate?: string;
}) {
  try {
    const user = await requireAuthUser();

    const cleanTitle = payload.title.trim();
    if (!cleanTitle) {
      return { success: false, message: "Nama cicilan tidak boleh kosong." };
    }

    if (!payload.amount || payload.amount <= 0) {
      return { success: false, message: "Nominal cicilan harus lebih besar dari Rp 0." };
    }

    // Pastikan tagihan tersebut ada dan memang dimiliki oleh user yang sedang login
    const existingBill = await prisma.bill.findFirst({
      where: {
        id: payload.id,
        userId: user.id,
      },
    });

    if (!existingBill) {
      return { success: false, message: "Data tagihan tidak ditemukan." };
    }

    // Lakukan pembaruan data pada tabel Bill
    await prisma.bill.update({
      where: { id: existingBill.id },
      data: {
        title: cleanTitle,
        amount: Math.round(payload.amount),
        ...(payload.dueDate ? { dueDate: new Date(payload.dueDate) } : {}),
      },
    });

    // Segarkan cache halaman /bills
    revalidatePath("/bills");

    return {
      success: true,
      message: "Data cicilan berhasil diperbarui!",
    };
  } catch (error) {
    console.error("Gagal memperbarui tagihan:", error);
    return {
      success: false,
      message: "Terjadi kesalahan saat memperbarui data cicilan.",
    };
  }
}

/**
 * 4. SERVER ACTION (DELETE): Menghapus data cicilan secara permanen dari tabel Bill
 * (Berguna untuk merapikan daftar cicilan yang sudah lunas atau salah input)
 * @param billId - ID unik tagihan yang akan dihapus
 */
export async function deleteBillAction(billId: string) {
  try {
    const user = await requireAuthUser();

    // Pastikan hanya menghapus tagihan milik user yang sedang login
    const deleted = await prisma.bill.deleteMany({
      where: {
        id: billId,
        userId: user.id,
      },
    });

    if (deleted.count === 0) {
      return { success: false, message: "Tagihan tidak ditemukan atau sudah dihapus." };
    }

    // Segarkan cache halaman /bills
    revalidatePath("/bills");

    return {
      success: true,
      message: "Tagihan berhasil dihapus secara permanen.",
    };
  } catch (error) {
    console.error("Gagal menghapus tagihan:", error);
    return {
      success: false,
      message: "Terjadi kesalahan saat menghapus tagihan.",
    };
  }
}

/**
 * 5. SERVER ACTION KHUSUS (PAY BILL): Menandai tagihan sebagai LUNAS (`isPaid = true`)
 * DAN secara otomatis membuat record baru di tabel `Transaction` dengan tipe `EXPENSE`
 * (kategori: "Cicilan/Utang") sebesar nominal tagihan tersebut agar keuntungan bersih di Dashboard langsung terpotong.
 *
 * Menggunakan `prisma.$transaction` (Database Transaction) agar kedua operasi berjalan secara atomik:
 * jika salah satu gagal, keduanya dibatalkan sehingga data keuangan tetap akurat dan konsisten.
 *
 * @param billId - ID unik tagihan yang akan dibayar
 */
export async function payBillAction(billId: string) {
  try {
    const user = await requireAuthUser();

    // 1. Cari tagihan berdasarkan ID dan pastikan milik user yang sedang login
    const bill = await prisma.bill.findFirst({
      where: {
        id: billId,
        userId: user.id,
      },
    });

    if (!bill) {
      return { success: false, message: "Tagihan tidak ditemukan." };
    }

    // 2. Cegah pembayaran ganda jika tagihan sudah berstatus lunas (isPaid === true)
    if (bill.isPaid) {
      return { success: false, message: "Tagihan ini sudah berstatus lunas." };
    }

    // 3. Jalankan transaksi database atomik menggunakan prisma.$transaction:
    //    a) Ubah status isPaid pada tabel Bill menjadi true
    //    b) Buat record pengeluaran baru (EXPENSE) dengan kategori "Cicilan/Utang" di tabel Transaction
    await prisma.$transaction([
      prisma.bill.update({
        where: { id: bill.id },
        data: { isPaid: true },
      }),
      prisma.transaction.create({
        data: {
          userId: user.id,
          type: "EXPENSE",
          amount: bill.amount,
          category: "Cicilan/Utang",
          date: new Date(),
        },
      }),
    ]);

    // 4. Revalidate halaman /bills DAN halaman Dashboard (/) agar:
    //    - Status tagihan di /bills langsung berubah menjadi Lunas
    //    - Pengeluaran Operasional & Keuntungan Bersih di Dashboard (/) langsung terpotong otomatis
    revalidatePath("/bills");
    revalidatePath("/");

    return {
      success: true,
      message: `Pembayaran "${bill.title}" berhasil dicatat dan memotong saldo keuntungan bersih!`,
    };
  } catch (error) {
    console.error("Gagal memproses pembayaran tagihan:", error);
    return {
      success: false,
      message: "Terjadi kesalahan saat memproses pembayaran tagihan.",
    };
  }
}
