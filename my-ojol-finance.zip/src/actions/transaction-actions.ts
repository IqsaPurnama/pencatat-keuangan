// File: src/actions/transaction-actions.ts
// Tujuan: Mengelola seluruh operasi database (Create, Read, Delete, serta Kalkulasi Dashboard)
// untuk entitas Transaction menggunakan arsitektur Serverless (Next.js Server Actions).

"use server";

import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/prisma";

// Tipe filter rentang waktu untuk kalkulasi di halaman Dashboard
export type TimeFilter = "DAILY" | "WEEKLY" | "MONTHLY";

// Struktur data untuk titik grafik tren keuangan di Dashboard
export interface ChartDataPoint {
  label: string;   // Label waktu (misal: "Sen", "Sel" atau tanggal "15 Nov")
  income: number;  // Total pendapatan pada periode titik tersebut
  expense: number; // Total pengeluaran pada periode titik tersebut
}

// Struktur data lengkap yang dikembalikan ke halaman Dashboard
export interface DashboardSummary {
  grossIncome: number;       // Pendapatan Kotor (Gross)
  operationalExpense: number; // Pengeluaran Operasional (Ops)
  takeHomePay: number;       // Keuntungan Bersih (Pendapatan Kotor - Pengeluaran Operasional)
  chartData: ChartDataPoint[]; // Data teragregasi untuk grafik bar/garis
  recentTransactions: {
    id: string;
    type: string;
    amount: number;
    category: string;
    date: Date;
  }[];
}

/**
 * Fungsi pembantu (Helper) untuk memverifikasi sesi pengguna yang sedang login.
 * Memastikan setiap Server Action hanya memproses data milik user yang sah.
 */
async function requireAuthUser() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user?.id) {
    throw new Error("Akses ditolak: Anda harus login terlebih dahulu.");
  }
  return session.user;
}

/**
 * 1. SERVER ACTION (READ & CALCULATE): Mengambil dan menghitung ringkasan keuangan untuk Dashboard
 * @param filter - Filter rentang waktu: "DAILY" (Hari ini), "WEEKLY" (7 hari terakhir), atau "MONTHLY" (Bulan ini)
 */
export async function getDashboardDataAction(
  filter: TimeFilter = "DAILY"
): Promise<DashboardSummary> {
  // Pastikan pengguna sudah terautentikasi dan ambil ID pengguna dari sesi
  const user = await requireAuthUser();
  const now = new Date();

  // Menentukan batas tanggal awal (startDate) berdasarkan filter waktu yang dipilih pengguna
  let startDate = new Date();

  if (filter === "DAILY") {
    // Filter Harian: Mulai dari pukul 00:00:00 hari ini
    startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  } else if (filter === "WEEKLY") {
    // Filter Mingguan: Mulai dari 6 hari yang lalu pukul 00:00:00 (total rentang 7 hari termasuk hari ini)
    startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6, 0, 0, 0, 0);
  } else if (filter === "MONTHLY") {
    // Filter Bulanan: Mulai dari tanggal 1 pada bulan dan tahun berjalan pukul 00:00:00
    startDate = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  }

  // Tarik seluruh transaksi milik pengguna yang sedang login dari tabel Transaction sesuai rentang waktu
  const transactions = await prisma.transaction.findMany({
    where: {
      userId: user.id,
      date: {
        gte: startDate, // Lebih besar atau sama dengan tanggal mulai (startDate)
      },
    },
    orderBy: {
      date: "desc", // Urutkan dari transaksi terbaru ke terlama
    },
  });

  // Inisialisasi variabel penampung untuk kalkulasi 3 Kartu Ringkasan Utama
  let grossIncome = 0;
  let operationalExpense = 0;

  // Melakukan iterasi pada setiap transaksi untuk menjumlahkan Pendapatan Kotor & Pengeluaran Operasional
  for (const tx of transactions) {
    if (tx.type === "INCOME") {
      // Menambahkan nominal ke Pendapatan Kotor jika tipe transaksi adalah INCOME
      grossIncome += tx.amount;
    } else if (tx.type === "EXPENSE") {
      // Menambahkan nominal ke Pengeluaran Operasional jika tipe transaksi adalah EXPENSE
      operationalExpense += tx.amount;
    }
  }

  // Menghitung Keuntungan Bersih (Take-Home Pay) = Pendapatan Kotor dikurangi Pengeluaran Operasional
  const takeHomePay = grossIncome - operationalExpense;

  // Menyusun data grafik (chartData) berdasarkan filter waktu agar mudah dibaca oleh driver ojol
  const chartData: ChartDataPoint[] = [];

  if (filter === "DAILY") {
    // Jika filter Harian: kelompokkan transaksi hari ini ke dalam 4 blok waktu kerja (Pagi, Siang, Sore, Malam)
    const timeSlots = [
      { label: "Pagi (00-10)", startHour: 0, endHour: 10, income: 0, expense: 0 },
      { label: "Siang (10-15)", startHour: 10, endHour: 15, income: 0, expense: 0 },
      { label: "Sore (15-19)", startHour: 15, endHour: 19, income: 0, expense: 0 },
      { label: "Malam (19-24)", startHour: 19, endHour: 24, income: 0, expense: 0 },
    ];

    for (const tx of transactions) {
      const txHour = new Date(tx.date).getHours();
      const slot = timeSlots.find((s) => txHour >= s.startHour && txHour < s.endHour);
      if (slot) {
        if (tx.type === "INCOME") slot.income += tx.amount;
        else slot.expense += tx.amount;
      }
    }

    for (const slot of timeSlots) {
      chartData.push({
        label: slot.label,
        income: slot.income,
        expense: slot.expense,
      });
    }
  } else if (filter === "WEEKLY") {
    // Jika filter Mingguan: buat 7 titik data untuk 7 hari terakhir (dari 6 hari lalu hingga hari ini)
    const dayNames = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
      const dayLabel = `${dayNames[d.getDay()]} ${d.getDate()}`;

      // Filter transaksi yang terjadi tepat pada tanggal `d`
      let dayIncome = 0;
      let dayExpense = 0;

      for (const tx of transactions) {
        const txDate = new Date(tx.date);
        if (
          txDate.getFullYear() === d.getFullYear() &&
          txDate.getMonth() === d.getMonth() &&
          txDate.getDate() === d.getDate()
        ) {
          if (tx.type === "INCOME") dayIncome += tx.amount;
          else dayExpense += tx.amount;
        }
      }

      chartData.push({
        label: dayLabel,
        income: dayIncome,
        expense: dayExpense,
      });
    }
  } else if (filter === "MONTHLY") {
    // Jika filter Bulanan: kelompokkan transaksi bulan ini ke dalam 4 Minggu (Minggu 1 s/d Minggu 4+)
    const weeks = [
      { label: "Minggu 1 (1-7)", minDay: 1, maxDay: 7, income: 0, expense: 0 },
      { label: "Minggu 2 (8-14)", minDay: 8, maxDay: 14, income: 0, expense: 0 },
      { label: "Minggu 3 (15-21)", minDay: 15, maxDay: 21, income: 0, expense: 0 },
      { label: "Minggu 4 (22+)", minDay: 22, maxDay: 31, income: 0, expense: 0 },
    ];

    for (const tx of transactions) {
      const dayOfMonth = new Date(tx.date).getDate();
      const weekBucket = weeks.find((w) => dayOfMonth >= w.minDay && dayOfMonth <= w.maxDay);
      if (weekBucket) {
        if (tx.type === "INCOME") weekBucket.income += tx.amount;
        else weekBucket.expense += tx.amount;
      }
    }

    for (const w of weeks) {
      chartData.push({
        label: w.label,
        income: w.income,
        expense: w.expense,
      });
    }
  }

  return {
    grossIncome,
    operationalExpense,
    takeHomePay,
    chartData,
    recentTransactions: transactions,
  };
}

/**
 * 2. SERVER ACTION (CREATE): Menyimpan transaksi baru dari halaman Form Input Cepat (/add)
 * @param payload - Objek berisi tipe transaksi ("INCOME" | "EXPENSE"), nominal (amount), dan kategori (category)
 */
export async function createTransactionAction(payload: {
  type: "INCOME" | "EXPENSE";
  amount: number;
  category: string;
}) {
  try {
    // 1. Verifikasi pengguna yang sedang login
    const user = await requireAuthUser();

    // 2. Validasi input: pastikan tipe transaksi valid, nominal lebih dari Rp 0, dan kategori telah dipilih
    if (payload.type !== "INCOME" && payload.type !== "EXPENSE") {
      return { success: false, message: "Tipe transaksi tidak valid." };
    }

    if (!payload.amount || payload.amount <= 0) {
      return { success: false, message: "Nominal transaksi harus lebih dari Rp 0." };
    }

    if (!payload.category || payload.category.trim() === "") {
      return { success: false, message: "Kategori wajib dipilih terlebih dahulu." };
    }

    // 3. Simpan record transaksi baru ke dalam tabel Transaction menggunakan Prisma
    await prisma.transaction.create({
      data: {
        userId: user.id,
        type: payload.type,
        amount: Math.round(payload.amount),
        category: payload.category.trim(),
        date: new Date(),
      },
    });

    // 4. Segarkan (revalidate) cache halaman Dashboard (/) agar angka kalkulasi langsung ter-update
    revalidatePath("/");

    return {
      success: true,
      message: "Transaksi berhasil disimpan!",
    };
  } catch (error) {
    console.error("Gagal menyimpan transaksi:", error);
    return {
      success: false,
      message: "Terjadi kesalahan saat menyimpan transaksi ke database.",
    };
  }
}

/**
 * 3. SERVER ACTION (DELETE): Menghapus transaksi jika pengguna salah menginput nominal di riwayat Dashboard
 * @param transactionId - ID unik dari transaksi yang ingin dihapus
 */
export async function deleteTransactionAction(transactionId: string) {
  try {
    const user = await requireAuthUser();

    // Pastikan transaksi yang akan dihapus benar-benar milik user yang sedang login
    await prisma.transaction.deleteMany({
      where: {
        id: transactionId,
        userId: user.id,
      },
    });

    // Revalidate halaman Dashboard agar ringkasan angka diperbarui otomatis
    revalidatePath("/");

    return {
      success: true,
      message: "Data transaksi berhasil dihapus.",
    };
  } catch (error) {
    console.error("Gagal menghapus transaksi:", error);
    return {
      success: false,
      message: "Gagal menghapus transaksi.",
    };
  }
}
