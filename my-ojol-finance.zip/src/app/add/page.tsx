// File: src/app/add/page.tsx
// Tujuan: Halaman Form Input Cepat (/add) dengan antarmuka Mobile-First yang sangat ramah jempol:
// 1. Sistem Tab Toggle (Pendapatan vs Pengeluaran)
// 2. Quick Increment Chips (+10rb, +20rb, +50rb, +100rb) yang langsung menjumlahkan nominal saat ditekan
// 3. Tombol Tap-to-Select untuk memilih kategori:
//    - Kategori Pendapatan: Gojek, Grab, Maxim, Tip
//    - Kategori Pengeluaran: Bensin, Makan, Parkir, Pulsa
// 4. Tombol "SIMPAN" berukuran penuh di bagian bawah untuk mengirim data via Server Action (createTransactionAction).

"use client";

import React, { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createTransactionAction } from "@/actions/transaction-actions";
import {
  ArrowDownLeft,
  ArrowUpRight,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Save,
  Sparkles,
  Fuel,
  Utensils,
  ParkingSquare,
  Smartphone,
  Bike,
  Coins,
} from "lucide-react";

// Daftar konstan Kategori Pendapatan sesuai spesifikasi
const INCOME_CATEGORIES = [
  { name: "Gojek", badgeColor: "bg-emerald-600", icon: Bike },
  { name: "Grab", badgeColor: "bg-green-600", icon: Bike },
  { name: "Maxim", badgeColor: "bg-amber-500", icon: Bike },
  { name: "Tip", badgeColor: "bg-teal-600", icon: Coins },
];

// Daftar konstan Kategori Pengeluaran sesuai spesifikasi
const EXPENSE_CATEGORIES = [
  { name: "Bensin", badgeColor: "bg-rose-600", icon: Fuel },
  { name: "Makan", badgeColor: "bg-orange-600", icon: Utensils },
  { name: "Parkir", badgeColor: "bg-slate-600", icon: ParkingSquare },
  { name: "Pulsa", badgeColor: "bg-blue-600", icon: Smartphone },
];

// Daftar konstan Quick Increment Chips (+10rb, +20rb, +50rb, +100rb)
const QUICK_CHIPS = [
  { label: "+10rb", value: 10_000 },
  { label: "+20rb", value: 20_000 },
  { label: "+50rb", value: 50_000 },
  { label: "+100rb", value: 100_000 },
];

export default function AddTransactionPage() {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  // 1. State untuk Tab Toggle Tipe Transaksi ("INCOME" untuk Pendapatan, "EXPENSE" untuk Pengeluaran)
  const [type, setType] = useState<"INCOME" | "EXPENSE">("INCOME");

  // 2. State untuk menyimpan nominal uang dalam bentuk angka (Default: 0)
  const [amount, setAmount] = useState<number>(0);

  // 3. State untuk menyimpan kategori yang sedang dipilih via tombol Tap-to-Select (Default: "Gojek")
  const [selectedCategory, setSelectedCategory] = useState<string>("Gojek");

  // 4. State untuk pesan umpan balik (Error / Sukses)
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  /**
   * Fungsi untuk berpindah tab antara Pendapatan (INCOME) dan Pengeluaran (EXPENSE).
   * Otomatis mengatur kategori default yang sesuai dengan tab yang dipilih.
   */
  const handleSwitchType = (newType: "INCOME" | "EXPENSE") => {
    setType(newType);
    setErrorMsg(null);
    setSuccessMsg(null);
    if (newType === "INCOME") {
      setSelectedCategory("Gojek");
    } else {
      setSelectedCategory("Bensin");
    }
  };

  /**
   * Fungsi untuk menjumlahkan nominal saat tombol Quick Increment Chip (+10rb, +20rb, +50rb, +100rb) ditekan.
   * Contoh: Jika nominal saat ini 20.000 lalu ditekan +50rb, nominal langsung menjadi 70.000.
   */
  const handleAddQuickAmount = (incrementValue: number) => {
    setErrorMsg(null);
    setAmount((prevAmount) => prevAmount + incrementValue);
  };

  /**
   * Fungsi untuk menangani perubahan input manual pada kolom angka jika driver ingin mengetik angka spesifik
   */
  const handleManualInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMsg(null);
    // Hapus semua karakter non-angka (seperti titik pemisah ribuan)
    const rawDigits = e.target.value.replace(/\D/g, "");
    const numericValue = rawDigits ? parseInt(rawDigits, 10) : 0;
    setAmount(numericValue);
  };

  /**
   * Fungsi untuk mengirim data transaksi ke Server Action saat tombol "SIMPAN" ditekan
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    // Validasi di sisi klien sebelum memanggil Server Action
    if (amount <= 0) {
      setErrorMsg("Nominal harus lebih dari Rp 0. Gunakan tombol +10rb s/d +100rb atau ketik nominal.");
      return;
    }

    if (!selectedCategory) {
      setErrorMsg("Silakan pilih salah satu kategori terlebih dahulu.");
      return;
    }

    // Menjalankan Server Action createTransactionAction secara asinkron
    startTransition(async () => {
      const result = await createTransactionAction({
        type,
        amount,
        category: selectedCategory,
      });

      if (!result.success) {
        setErrorMsg(result.message);
        return;
      }

      // Tampilkan pesan sukses, reset nominal, lalu arahkan kembali ke halaman Dashboard (/)
      setSuccessMsg(result.message);
      setAmount(0);
      router.push("/");
      router.refresh();
    });
  };

  // Menentukan daftar kategori aktif yang dirender berdasarkan tab yang dipilih
  const activeCategories =
    type === "INCOME" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const isIncome = type === "INCOME";

  return (
    <div className="flex flex-col space-y-5 px-4 pt-5 pb-8">
      {/* Judul Halaman */}
      <header>
        <h1 className="text-xl font-extrabold tracking-tight text-slate-900">
          Catat Transaksi Cepat
        </h1>
        <p className="text-xs font-medium text-slate-500">
          Tap tombol nominal & kategori untuk mencatat dalam hitungan detik.
        </p>
      </header>

      {/* 1. SISTEM TAB TOGGLE: Pendapatan vs Pengeluaran */}
      <section aria-label="Pilih Jenis Transaksi">
        <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-200/90 p-1.5">
          <button
            type="button"
            id="tab-income"
            onClick={() => handleSwitchType("INCOME")}
            className={`flex min-h-[52px] items-center justify-center gap-2 rounded-xl text-sm font-extrabold transition-all active:scale-95 ${
              isIncome
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <ArrowDownLeft className="h-5 w-5" />
            <span>Pendapatan</span>
          </button>

          <button
            type="button"
            id="tab-expense"
            onClick={() => handleSwitchType("EXPENSE")}
            className={`flex min-h-[52px] items-center justify-center gap-2 rounded-xl text-sm font-extrabold transition-all active:scale-95 ${
              !isIncome
                ? "bg-rose-600 text-white shadow-md shadow-rose-600/20"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <ArrowUpRight className="h-5 w-5" />
            <span>Pengeluaran</span>
          </button>
        </div>
      </section>

      {/* Form Utama */}
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Kotak Tampilan & Input Nominal Uang + Quick Increment Chips */}
        <section
          aria-label="Nominal Transaksi"
          className={`rounded-3xl border-2 bg-white p-5 shadow-sm transition-colors ${
            isIncome ? "border-emerald-500/40" : "border-rose-500/40"
          }`}
        >
          <div className="flex items-center justify-between">
            <label
              htmlFor="input-amount"
              className="text-xs font-extrabold uppercase tracking-wider text-slate-500"
            >
              Nominal {isIncome ? "Pendapatan" : "Pengeluaran"}
            </label>

            {/* Tombol Reset untuk mengembalikan nominal menjadi Rp 0 dengan satu ketukan */}
            {amount > 0 && (
              <button
                type="button"
                id="btn-reset-amount"
                onClick={() => setAmount(0)}
                className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600 transition hover:bg-slate-200 active:scale-95"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Reset Rp 0</span>
              </button>
            )}
          </div>

          {/* Input Nominal Berukuran Sangat Besar agar jelas terlihat di bawah sinar matahari */}
          <div className="mt-2 flex items-baseline gap-2 border-b border-slate-200 pb-3">
            <span
              className={`text-2xl font-black ${
                isIncome ? "text-emerald-600" : "text-rose-600"
              }`}
            >
              Rp
            </span>
            <input
              id="input-amount"
              type="text"
              inputMode="numeric"
              value={amount === 0 ? "" : amount.toLocaleString("id-ID")}
              onChange={handleManualInputChange}
              placeholder="0"
              className="w-full bg-transparent text-4xl font-black tracking-tight text-slate-900 placeholder:text-slate-300 focus:outline-none"
            />
          </div>

          {/* 2. QUICK INCREMENT CHIPS: Tombol +10rb, +20rb, +50rb, +100rb */}
          <div className="mt-4">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-bold text-slate-500">
              <Sparkles className="h-3.5 w-3.5 text-amber-500" />
              <span>Tambah Cepat (Langsung Menjumlahkan):</span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {QUICK_CHIPS.map((chip) => (
                <button
                  key={chip.value}
                  type="button"
                  id={`chip-add-${chip.value}`}
                  onClick={() => handleAddQuickAmount(chip.value)}
                  className={`flex min-h-[50px] items-center justify-center rounded-2xl border text-sm font-extrabold shadow-sm transition-all active:scale-95 ${
                    isIncome
                      ? "border-emerald-200 bg-emerald-50/80 text-emerald-800 hover:bg-emerald-100 active:bg-emerald-200"
                      : "border-rose-200 bg-rose-50/80 text-rose-800 hover:bg-rose-100 active:bg-rose-200"
                  }`}
                >
                  {chip.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* 3. KATEGORI TAP-TO-SELECT (Tombol Besar untuk Memilih Kategori) */}
        <section
          aria-label="Pilih Kategori"
          className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
        >
          <span className="block text-xs font-extrabold uppercase tracking-wider text-slate-500">
            Pilih Kategori {isIncome ? "Pendapatan" : "Pengeluaran"} (Tap)
          </span>

          <div className="mt-3 grid grid-cols-2 gap-3">
            {activeCategories.map((cat) => {
              const isSelected = selectedCategory === cat.name;
              const IconComp = cat.icon;

              return (
                <button
                  key={cat.name}
                  type="button"
                  id={`category-btn-${cat.name.toLowerCase()}`}
                  onClick={() => setSelectedCategory(cat.name)}
                  className={`flex min-h-[64px] items-center gap-3 rounded-2xl border-2 p-3.5 text-left transition-all active:scale-95 ${
                    isSelected
                      ? isIncome
                        ? "border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-sm ring-2 ring-emerald-500/20"
                        : "border-rose-600 bg-rose-50/70 text-rose-950 shadow-sm ring-2 ring-rose-500/20"
                      : "border-slate-200 bg-slate-50/60 text-slate-700 hover:border-slate-300 hover:bg-slate-100"
                  }`}
                >
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow-sm ${cat.badgeColor}`}
                  >
                    <IconComp className="h-5 w-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-base font-extrabold leading-tight">
                      {cat.name}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500">
                      {isSelected ? "Terpilih ✓" : "Ketuk pilih"}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Pesan Notifikasi Error / Sukses */}
        {errorMsg && (
          <div
            role="alert"
            className="flex items-center gap-2.5 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-xs font-bold text-rose-700"
          >
            <AlertCircle className="h-5 w-5 shrink-0 text-rose-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div
            role="status"
            className="flex items-center gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-xs font-bold text-emerald-800"
          >
            <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* 4. TOMBOL "SIMPAN" BERUKURAN PENUH DI BAGIAN BAWAH */}
        <button
          type="submit"
          id="btn-save-transaction"
          disabled={isPending}
          className={`flex min-h-[60px] w-full items-center justify-center gap-2.5 rounded-2xl px-6 py-4 text-base font-black tracking-wide text-white shadow-lg transition-all active:scale-[0.99] disabled:opacity-60 ${
            isIncome
              ? "bg-emerald-600 shadow-emerald-600/25 hover:bg-emerald-700"
              : "bg-rose-600 shadow-rose-600/25 hover:bg-rose-700"
          }`}
        >
          <Save className="h-5 w-5" />
          <span>
            {isPending
              ? "MENYIMPAN DATA..."
              : `SIMPAN ${isIncome ? "PENDAPATAN" : "PENGELUARAN"}`}
          </span>
        </button>
      </form>
    </div>
  );
}
