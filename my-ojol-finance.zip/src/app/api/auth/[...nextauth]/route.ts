// File: src/app/api/auth/[...nextauth]/route.ts
// Tujuan: Route Handler untuk menangani seluruh endpoint autentikasi NextAuth.js
// (seperti /api/auth/signin, /api/auth/signout, /api/auth/session, dan /api/auth/callback).

import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth";

// Membuat handler NextAuth menggunakan konfigurasi authOptions yang telah didefinisikan di src/lib/auth.ts
const handler = NextAuth(authOptions);

// Mengekspor handler untuk metode HTTP GET dan POST sesuai standar Next.js 14 App Router
export { handler as GET, handler as POST };
