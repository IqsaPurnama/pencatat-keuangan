// File: src/app/bills/page.tsx
// Tujuan: Halaman Modul Pengingat Utang & Tagihan (/bills) yang berjalan sebagai Server Component.
// Menarik seluruh daftar tagihan milik user yang sedang login langsung dari tabel `Bill` melalui Prisma
// dan merendernya menggunakan komponen interaktif `BillsClient`.

import React from "react";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { getBillsAction } from "@/actions/bill-actions";
import BillsClient from "@/components/BillsClient";

// Memastikan halaman selalu mengambil daftar tagihan terbaru dari database
export const dynamic = "force-dynamic";

export default async function BillsPage() {
  // 1. Verifikasi sesi pengguna yang sedang login
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    redirect("/login");
  }

  // 2. Mengambil daftar tagihan/cicilan milik user dari database menggunakan Server Action `getBillsAction`
  const bills = await getBillsAction();

  return (
    <div className="flex flex-col space-y-5 px-4 pt-5 pb-8">
      {/* Header Halaman Tagihan */}
      <header>
        <h1 className="text-xl font-extrabold tracking-tight text-slate-900">
          Pengingat Utang & Tagihan
        </h1>
        <p className="text-xs font-medium text-slate-500">
          Kelola jadwal cicilan dan bayar tepat waktu agar keuangan tetap sehat.
        </p>
      </header>

      {/* Komponen Klien untuk menangani interaksi CRUD (Create, Edit, Delete) dan tombol Bayar */}
      <BillsClient initialBills={bills} />
    </div>
  );
}
