// File: src/app/layout.tsx
// Tujuan: Root Layout utama aplikasi Next.js 14 App Router.
// Membungkus seluruh halaman dengan kontainer berukuran mobile-first (max-w-md di tengah layar)
// serta menyertakan komponen navigasi bawah (BottomNav) yang menghubungkan rute /, /add, dan /bills.

import type { Metadata, Viewport } from "next";
import "./globals.css";
import AuthSessionProvider from "@/components/AuthSessionProvider";
import BottomNav from "@/components/BottomNav";

// Metadata SEO dan informasi aplikasi
export const metadata: Metadata = {
  title: "My Ojol Finance — Catatan Keuangan Harian Driver Ojol",
  description:
    "Aplikasi pencatatan keuangan harian mobile-first untuk pengemudi ojek online (Gojek, Grab, Maxim). Pantau pendapatan kotor, biaya bensin, keuntungan bersih, dan cicilan.",
};

// Pengaturan viewport agar tampilan pas di layar smartphone tanpa zoom tidak sengaja saat mengetuk tombol
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className="min-h-screen bg-slate-200/70 text-slate-900">
        <AuthSessionProvider>
          {/* Kerangka Mobile-First: Membatasi lebar maksimum seukuran layar ponsel (max-w-md)
              agar nyaman dioperasikan dengan satu tangan (jempol) baik di HP maupun saat dibuka di desktop */}
          <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col bg-slate-50 shadow-xl">
            {/* Konten halaman aktif dengan padding bawah (pb-28) agar tidak tertutup oleh BottomNav */}
            <main className="flex-1 pb-28">{children}</main>

            {/* Navigasi Bawah (Bottom Navigation) untuk berpindah antara /, /add, dan /bills */}
            <BottomNav />
          </div>
        </AuthSessionProvider>
      </body>
    </html>
  );
}
