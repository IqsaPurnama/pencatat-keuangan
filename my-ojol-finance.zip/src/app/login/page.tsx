// File: src/app/login/page.tsx
// Tujuan: Halaman Autentikasi (Login & Registrasi Akun) menggunakan NextAuth.js Credentials Provider.
// Dirancang dengan tombol dan kolom input berukuran besar (touch-friendly) untuk layar smartphone driver ojol.

"use client";

import React, { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { registerUserAction } from "@/actions/auth-actions";
import { Bike, Lock, User, ArrowRight, CheckCircle2, AlertCircle } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();

  // State untuk menentukan apakah pengguna sedang dalam mode "LOGIN" atau "REGISTER" (Daftar Akun Baru)
  const [mode, setMode] = useState<"LOGIN" | "REGISTER">("LOGIN");

  // State untuk menyimpan nilai input Username dan Password
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  // State untuk menangani indikator loading dan pesan umpan balik (error / sukses)
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  /**
   * Fungsi handler saat form Login atau Register dikirimkan oleh pengguna
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setIsLoading(true);

    try {
      // JIKA MODE REGISTER: Daftarkan akun baru terlebih dahulu melalui Server Action
      if (mode === "REGISTER") {
        const regResult = await registerUserAction(username, password);
        if (!regResult.success) {
          setErrorMsg(regResult.message);
          setIsLoading(false);
          return;
        }
        setSuccessMsg(regResult.message);
      }

      // PROSES LOGIN: Memanggil fungsi `signIn("credentials")` dari NextAuth.js
      // `redirect: false` digunakan agar kita bisa menangani pesan error langsung di halaman ini tanpa reload penuh
      const res = await signIn("credentials", {
        username: username.trim(),
        password,
        redirect: false,
      });

      if (res?.error) {
        setErrorMsg(res.error);
        setIsLoading(false);
        return;
      }

      // Jika login berhasil, arahkan pengguna ke halaman utama Dashboard (/) dan segarkan data Server Component
      router.push("/");
      router.refresh();
    } catch (err) {
      console.error("Error saat autentikasi:", err);
      setErrorMsg("Terjadi gangguan jaringan. Silakan coba lagi.");
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col justify-between bg-gradient-to-b from-emerald-700 via-emerald-800 to-slate-900 p-6 text-white">
      {/* Bagian Atas: Identitas Visual & Branding Aplikasi */}
      <div className="mt-8 flex flex-col items-center text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white/15 shadow-inner backdrop-blur-md ring-2 ring-white/30">
          <Bike className="h-11 w-11 text-emerald-300" />
        </div>
        <h1 className="mt-4 text-2xl font-extrabold tracking-tight text-white">
          My Ojol Finance
        </h1>
        <p className="mt-1.5 max-w-xs text-sm text-emerald-100/90">
          Catatan Keuangan Harian & Pengingat Cicilan Khusus Driver Ojek Online
        </p>
      </div>

      {/* Bagian Tengah: Kartu Form Login / Register */}
      <div className="my-6 rounded-3xl bg-white p-6 text-slate-900 shadow-2xl">
        {/* Tab Toggle antara Masuk (Login) dan Daftar Akun Baru (Register) */}
        <div className="mb-6 grid grid-cols-2 rounded-2xl bg-slate-100 p-1.5">
          <button
            type="button"
            id="tab-mode-login"
            onClick={() => {
              setMode("LOGIN");
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`min-h-[46px] rounded-xl text-sm font-bold transition-all ${
              mode === "LOGIN"
                ? "bg-white text-emerald-700 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Masuk Akun
          </button>
          <button
            type="button"
            id="tab-mode-register"
            onClick={() => {
              setMode("REGISTER");
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`min-h-[46px] rounded-xl text-sm font-bold transition-all ${
              mode === "REGISTER"
                ? "bg-white text-emerald-700 shadow-sm"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            Daftar Baru
          </button>
        </div>

        {/* Notifikasi Pesan Error jika validasi gagal */}
        {errorMsg && (
          <div
            role="alert"
            className="mb-4 flex items-start gap-2.5 rounded-2xl border border-rose-200 bg-rose-50 p-3.5 text-xs font-semibold text-rose-700"
          >
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-600 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Notifikasi Pesan Sukses */}
        {successMsg && (
          <div
            role="status"
            className="mb-4 flex items-start gap-2.5 rounded-2xl border border-emerald-200 bg-emerald-50 p-3.5 text-xs font-semibold text-emerald-800"
          >
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Form Input Kredensial */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="input-username"
              className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-600"
            >
              Username Driver
            </label>
            <div className="relative">
              <User className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                id="input-username"
                name="username"
                type="text"
                required
                autoComplete="username"
                placeholder="Contoh: bang_ojol"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="min-h-[54px] w-full rounded-2xl border border-slate-300 bg-slate-50 pl-12 pr-4 text-base font-semibold text-slate-900 placeholder:font-normal placeholder:text-slate-400 focus:border-emerald-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="input-password"
              className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-slate-600"
            >
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                id="input-password"
                name="password"
                type="password"
                required
                autoComplete={
                  mode === "LOGIN" ? "current-password" : "new-password"
                }
                placeholder="Masukkan password..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="min-h-[54px] w-full rounded-2xl border border-slate-300 bg-slate-50 pl-12 pr-4 text-base font-semibold text-slate-900 placeholder:font-normal placeholder:text-slate-400 focus:border-emerald-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          {/* Tombol Aksi Utama Berukuran Besar (Touch-Friendly) */}
          <button
            type="submit"
            id="btn-submit-auth"
            disabled={isLoading}
            className="mt-2 flex min-h-[56px] w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-6 py-4 text-base font-extrabold text-white shadow-lg shadow-emerald-600/25 transition-all hover:bg-emerald-700 active:scale-[0.99] disabled:opacity-60"
          >
            {isLoading ? (
              <span>Memproses...</span>
            ) : mode === "LOGIN" ? (
              <>
                <span>MASUK SEKARANG</span>
                <ArrowRight className="h-5 w-5" />
              </>
            ) : (
              <>
                <span>DAFTAR & MASUK</span>
                <ArrowRight className="h-5 w-5" />
              </>
            )}
          </button>
        </form>
      </div>

      {/* Bagian Bawah: Footer Informasi Singkat */}
      <p className="text-center text-xs text-emerald-100/75">
        Aman, Cepat & Ringan di HP • Siap Gaspol Cari Orderan
      </p>
    </div>
  );
}
