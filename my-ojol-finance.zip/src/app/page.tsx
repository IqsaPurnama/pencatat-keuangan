// File: src/app/page.tsx
// Tujuan: Halaman Utama Dashboard Keuangan (/) yang berjalan sebagai Server Component.
// Menarik data transaksi milik user yang sedang login langsung dari database menggunakan Server Action,
// menampilkan filter waktu (Harian, Mingguan, Bulanan), 3 Kartu Ringkasan Utama (Kalkulasi Otomatis),
// Grafik Tren Keuangan, serta Daftar Riwayat Transaksi.

import React from "react";
import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import {
  getDashboardDataAction,
  TimeFilter,
} from "@/actions/transaction-actions";
import FinanceChart from "@/components/FinanceChart";
import {
  LogoutButton,
  DeleteTransactionButton,
} from "@/components/DashboardClient";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Plus,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
} from "lucide-react";

/**
 * Fungsi utilitas untuk memformat angka integer menjadi format mata uang Rupiah (contoh: Rp 150.000)
 */
function formatRupiah(amount: number): string {
  const isNegative = amount < 0;
  const formatted = Math.abs(amount).toLocaleString("id-ID");
  return `${isNegative ? "-Rp " : "Rp "}${formatted}`;
}

// Memastikan halaman selalu mengambil data terbaru secara dinamis setiap kali dibuka
export const dynamic = "force-dynamic";

export default async function DashboardPage({
  searchParams,
}: {
  searchParams?: { filter?: string };
}) {
  // 1. Mengecek sesi login pengguna di sisi server
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    redirect("/login");
  }

  // 2. Membaca parameter filter waktu dari URL (?filter=DAILY | WEEKLY | MONTHLY)
  // Jika tidak ada parameter, gunakan default "DAILY" (Harian)
  const rawFilter = searchParams?.filter?.toUpperCase();
  const activeFilter: TimeFilter =
    rawFilter === "WEEKLY" || rawFilter === "MONTHLY" ? rawFilter : "DAILY";

  // 3. Memanggil Server Action untuk mengambil data transaksi & hasil kalkulasi otomatis dari Prisma
  const dashboardData = await getDashboardDataAction(activeFilter);

  // Pemetaan label bahasa Indonesia untuk filter waktu yang sedang aktif
  const filterLabels: Record<TimeFilter, string> = {
    DAILY: "Hari Ini",
    WEEKLY: "7 Hari Terakhir",
    MONTHLY: "Bulan Ini",
  };

  return (
    <div className="flex flex-col space-y-5 pb-6">
      {/* Bagian Header: Sapaan Driver, Tombol Logout, dan Kartu Utama Keuntungan Bersih (Take-Home Pay) */}
      <header className="rounded-b-3xl bg-gradient-to-br from-emerald-700 via-emerald-800 to-slate-900 px-5 pt-6 pb-7 text-white shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-emerald-200">
              Salam Satu Aspal,
            </p>
            <h1 className="text-xl font-extrabold tracking-tight text-white">
              Bang {session.user.username}
            </h1>
          </div>
          <LogoutButton />
        </div>

        {/* KARTU RINGKASAN 1 (UTAMA): Keuntungan Bersih / Take-Home Pay (Pendapatan Kotor - Pengeluaran Operasional) */}
        <div
          id="card-take-home-pay"
          className="mt-5 rounded-2xl bg-white/10 p-4 backdrop-blur-md ring-1 ring-white/20"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-100">
              Keuntungan Bersih (Take-Home Pay)
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[11px] font-bold text-emerald-200 ring-1 ring-emerald-400/30">
              <Calendar className="h-3 w-3" />
              {filterLabels[activeFilter]}
            </span>
          </div>

          <p
            className={`mt-2 text-3xl font-black tracking-tight ${
              dashboardData.takeHomePay < 0 ? "text-rose-300" : "text-white"
            }`}
          >
            {formatRupiah(dashboardData.takeHomePay)}
          </p>

          <p className="mt-1 text-xs text-emerald-100/80">
            Uang bersih siap dibawa pulang setelah dipotong bensin, makan & cicilan.
          </p>
        </div>
      </header>

      <div className="space-y-5 px-4">
        {/* Filter Waktu Sederhana: Harian, Mingguan, Bulanan (Touch-Friendly Pills) */}
        <section aria-label="Filter Rentang Waktu">
          <div className="grid grid-cols-3 gap-2 rounded-2xl bg-slate-200/80 p-1.5">
            {(
              [
                { key: "DAILY", label: "Harian" },
                { key: "WEEKLY", label: "Mingguan" },
                { key: "MONTHLY", label: "Bulanan" },
              ] as { key: TimeFilter; label: string }[]
            ).map((tab) => {
              const isSelected = activeFilter === tab.key;
              return (
                <Link
                  key={tab.key}
                  id={`filter-${tab.key.toLowerCase()}`}
                  href={`/?filter=${tab.key}`}
                  className={`flex min-h-[44px] items-center justify-center rounded-xl text-xs font-extrabold transition-all active:scale-95 ${
                    isSelected
                      ? "bg-white text-emerald-700 shadow-sm"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {tab.label}
                </Link>
              );
            })}
          </div>
        </section>

        {/* KARTU RINGKASAN 2 & 3: Pendapatan Kotor (Gross) dan Pengeluaran Operasional (Ops) */}
        <section
          aria-label="Kartu Ringkasan Pendapatan dan Pengeluaran"
          className="grid grid-cols-2 gap-3"
        >
          {/* KARTU 2: Pendapatan Kotor (Gross) */}
          <div
            id="card-gross-income"
            className="flex flex-col justify-between rounded-2xl border border-emerald-200/80 bg-white p-4 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">
                Pendapatan Kotor
              </span>
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                <TrendingUp className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-lg font-extrabold text-emerald-700">
                {formatRupiah(dashboardData.grossIncome)}
              </p>
              <span className="text-[11px] font-medium text-slate-400">
                Total Orderan & Tip (Gross)
              </span>
            </div>
          </div>

          {/* KARTU 3: Pengeluaran Operasional (Ops) */}
          <div
            id="card-operational-expense"
            className="flex flex-col justify-between rounded-2xl border border-rose-200/80 bg-white p-4 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">
                Pengeluaran (Ops)
              </span>
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
                <TrendingDown className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-lg font-extrabold text-rose-600">
                {formatRupiah(dashboardData.operationalExpense)}
              </p>
              <span className="text-[11px] font-medium text-slate-400">
                Bensin, Makan, Parkir, Utang
              </span>
            </div>
          </div>
        </section>

        {/* Integrasi Grafik Tren Keuangan (Bar Chart) */}
        <FinanceChart
          data={dashboardData.chartData}
          filterLabel={filterLabels[activeFilter]}
        />

        {/* Daftar Riwayat Transaksi Terakhir */}
        <section
          aria-label="Riwayat Transaksi"
          className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
        >
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-slate-500" />
              <h2 className="text-sm font-bold text-slate-800">
                Riwayat Transaksi ({filterLabels[activeFilter]})
              </h2>
            </div>
            <Link
              href="/add"
              className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Tambah</span>
            </Link>
          </div>

          {/* Jika belum ada transaksi pada periode waktu ini, tampilkan informasi kosong */}
          {dashboardData.recentTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 py-8 text-center">
              <Wallet className="h-9 w-9 text-slate-300" />
              <p className="mt-2 text-sm font-bold text-slate-600">
                Belum ada catatan transaksi
              </p>
              <p className="mt-0.5 max-w-xs text-xs text-slate-400">
                Tekan tombol &quot;Catat Cepat&quot; di bawah untuk mulai mencatat pendapatan atau pengeluaran hari ini.
              </p>
              <Link
                href="/add"
                className="mt-4 inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white shadow-sm hover:bg-emerald-700"
              >
                <Plus className="h-4 w-4" />
                <span>Catat Transaksi Sekarang</span>
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {dashboardData.recentTransactions.map((tx) => {
                const isIncome = tx.type === "INCOME";
                const formattedTime = new Date(tx.date).toLocaleDateString(
                  "id-ID",
                  {
                    day: "numeric",
                    month: "short",
                    hour: "2-digit",
                    minute: "2-digit",
                  }
                );

                return (
                  <li
                    key={tx.id}
                    className="flex items-center justify-between py-3 first:pt-1 last:pb-1"
                  >
                    <div className="flex items-center gap-3">
                      {/* Ikon Indikator Pemasukan (Hijau) vs Pengeluaran (Merah) */}
                      <div
                        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${
                          isIncome
                            ? "bg-emerald-50 text-emerald-600"
                            : "bg-rose-50 text-rose-600"
                        }`}
                      >
                        {isIncome ? (
                          <ArrowUpRight className="h-5 w-5" />
                        ) : (
                          <ArrowDownRight className="h-5 w-5" />
                        )}
                      </div>

                      <div>
                        <p className="text-sm font-bold text-slate-800">
                          {tx.category}
                        </p>
                        <p className="text-xs font-medium text-slate-400">
                          {isIncome ? "Pendapatan" : "Pengeluaran"} •{" "}
                          {formattedTime}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-sm font-extrabold ${
                          isIncome ? "text-emerald-600" : "text-rose-600"
                        }`}
                      >
                        {isIncome ? "+" : "-"}
                        {formatRupiah(tx.amount)}
                      </span>
                      <DeleteTransactionButton id={tx.id} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
