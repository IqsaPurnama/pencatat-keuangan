// File: src/components/AuthSessionProvider.tsx
// Tujuan: Membungkus aplikasi dengan SessionProvider dari NextAuth.js di sisi Client Component
// agar informasi sesi login dapat diakses di seluruh komponen klien.

"use client";

import { SessionProvider } from "next-auth/react";
import React from "react";

export default function AuthSessionProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  // Mengembalikan SessionProvider yang menyalurkan state autentikasi ke seluruh pohon komponen anak
  return <SessionProvider>{children}</SessionProvider>;
}
