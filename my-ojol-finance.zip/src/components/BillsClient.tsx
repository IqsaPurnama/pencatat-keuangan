// File: src/components/BillsClient.tsx
// Tujuan: Komponen interaktif di halaman Pengingat Utang & Tagihan (/bills) yang menangani:
// 1. Form untuk menambah cicilan/tagihan baru (CREATE - createBillAction)
// 2. Opsi Edit nama atau nominal cicilan secara langsung / inline (UPDATE - updateBillAction)
// 3. Opsi Delete untuk menghapus cicilan secara permanen (DELETE - deleteBillAction)
// 4. Tombol Aksi "Bayar" pada tagihan belum lunas yang otomatis mengubah status `isPaid = true`
//    DAN membuat record `Transaction` baru bertipe `EXPENSE` (kategori: "Cicilan/Utang")
//    sebesar nominal tagihan tersebut sehingga keuntungan bersih di Dashboard langsung terpotong (payBillAction).

"use client";

import React, { useState, useTransition } from "react";
import {
  createBillAction,
  updateBillAction,
  deleteBillAction,
  payBillAction,
} from "@/actions/bill-actions";
import {
  PlusCircle,
  CheckCircle2,
  Clock,
  Pencil,
  Trash2,
  X,
  Check,
  CreditCard,
  AlertCircle,
  CalendarDays,
} from "lucide-react";

// Tipe data satu item Bill yang diterima dari Server Component
export interface BillItem {
  id: string;
  userId: string;
  title: string;
  amount: number;
  dueDate: Date | string;
  isPaid: boolean;
}

/**
 * Fungsi utilitas untuk memformat angka menjadi mata uang Rupiah (contoh: Rp 450.000)
 */
function formatRupiah(amount: number): string {
  return `Rp ${amount.toLocaleString("id-ID")}`;
}

export default function BillsClient({
  initialBills,
}: {
  initialBills: BillItem[];
}) {
  const [isPending, startTransition] = useTransition();

  // State untuk menampilkan pesan umpan balik (Sukses / Error) setelah operasi CRUD atau Bayar
  const [feedback, setFeedback] = useState<{
    type: "SUCCESS" | "ERROR";
    text: string;
  } | null>(null);

  // State untuk Form Tambah Cicilan Baru (Create)
  const [title, setTitle] = useState("");
  const [amountStr, setAmountStr] = useState("");
  const [dueDate, setDueDate] = useState(() => {
    // Default tanggal jatuh tempo adalah hari ini dalam format YYYY-MM-DD
    const today = new Date();
    return today.toISOString().split("T")[0];
  });

  // State untuk Mode Edit Cicilan (Update): menyimpan ID cicilan yang sedang diedit beserta nilai perubahannya
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editAmountStr, setEditAmountStr] = useState("");

  /**
   * 1. HANDLER CREATE: Menambahkan cicilan/tagihan baru melalui Server Action `createBillAction`
   */
  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const numericAmount = parseInt(amountStr.replace(/\D/g, ""), 10) || 0;

    if (!title.trim()) {
      setFeedback({
        type: "ERROR",
        text: "Nama cicilan/utang wajib diisi (contoh: Cicilan Motor Beat).",
      });
      return;
    }

    if (numericAmount <= 0) {
      setFeedback({
        type: "ERROR",
        text: "Nominal cicilan harus lebih besar dari Rp 0.",
      });
      return;
    }

    startTransition(async () => {
      const res = await createBillAction({
        title,
        amount: numericAmount,
        dueDate,
      });

      if (!res.success) {
        setFeedback({ type: "ERROR", text: res.message });
        return;
      }

      // Reset form input setelah berhasil disimpan
      setTitle("");
      setAmountStr("");
      setFeedback({ type: "SUCCESS", text: res.message });
    });
  };

  /**
   * Memulai mode Edit pada salah satu kartu cicilan
   */
  const handleStartEdit = (bill: BillItem) => {
    setFeedback(null);
    setEditingId(bill.id);
    setEditTitle(bill.title);
    setEditAmountStr(bill.amount.toString());
  };

  /**
   * 2. HANDLER UPDATE: Menyimpan perubahan nama atau nominal cicilan melalui Server Action `updateBillAction`
   */
  const handleSaveEdit = (billId: string) => {
    setFeedback(null);
    const numericAmount = parseInt(editAmountStr.replace(/\D/g, ""), 10) || 0;

    if (!editTitle.trim() || numericAmount <= 0) {
      setFeedback({
        type: "ERROR",
        text: "Nama cicilan tidak boleh kosong dan nominal harus lebih dari Rp 0.",
      });
      return;
    }

    startTransition(async () => {
      const res = await updateBillAction({
        id: billId,
        title: editTitle,
        amount: numericAmount,
      });

      if (!res.success) {
        setFeedback({ type: "ERROR", text: res.message });
        return;
      }

      setEditingId(null);
      setFeedback({ type: "SUCCESS", text: res.message });
    });
  };

  /**
   * 3. HANDLER DELETE: Menghapus cicilan secara permanen melalui Server Action `deleteBillAction`
   */
  const handleDeleteBill = (billId: string) => {
    setFeedback(null);
    startTransition(async () => {
      const res = await deleteBillAction(billId);
      if (!res.success) {
        setFeedback({ type: "ERROR", text: res.message });
        return;
      }
      setFeedback({ type: "SUCCESS", text: res.message });
    });
  };

  /**
   * 4. HANDLER BAYAR TAGIHAN: Memanggil Server Action `payBillAction` yang:
   *    - Mengubah status `isPaid` menjadi `true`
   *    - Otomatis membuat record baru di tabel `Transaction` bertipe `EXPENSE` (kategori: "Cicilan/Utang")
   *      sebesar nominal tagihan tersebut agar keuntungan bersih di Dashboard langsung terpotong.
   */
  const handlePayBill = (billId: string) => {
    setFeedback(null);
    startTransition(async () => {
      const res = await payBillAction(billId);
      if (!res.success) {
        setFeedback({ type: "ERROR", text: res.message });
        return;
      }
      setFeedback({ type: "SUCCESS", text: res.message });
    });
  };

  // Menghitung ringkasan total tagihan yang belum dibayar agar driver tahu beban kewajiban saat ini
  const unpaidBills = initialBills.filter((b) => !b.isPaid);
  const totalUnpaidAmount = unpaidBills.reduce((acc, b) => acc + b.amount, 0);

  return (
    <div className="space-y-5">
      {/* Kartu Ringkasan Beban Tagihan Belum Lunas */}
      <section
        aria-label="Ringkasan Tagihan Belum Lunas"
        className="rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 p-5 text-white shadow-lg"
      >
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
            Total Tagihan Belum Lunas
          </span>
          <span className="rounded-full bg-amber-500/20 px-2.5 py-0.5 text-xs font-extrabold text-amber-300 ring-1 ring-amber-400/30">
            {unpaidBills.length} Tagihan Aktif
          </span>
        </div>

        <p className="mt-2 text-3xl font-black tracking-tight text-white">
          {formatRupiah(totalUnpaidAmount)}
        </p>

        <p className="mt-1 text-xs text-slate-300">
          Menekan tombol <strong className="text-emerald-300">Bayar</strong> akan otomatis mencatat pengeluaran &quot;Cicilan/Utang&quot; &amp; memotong Keuntungan Bersih di Dashboard.
        </p>
      </section>

      {/* Notifikasi Umpan Balik Operasi CRUD / Pembayaran */}
      {feedback && (
        <div
          role="alert"
          className={`flex items-start gap-2.5 rounded-2xl border p-4 text-xs font-bold ${
            feedback.type === "SUCCESS"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-rose-200 bg-rose-50 text-rose-700"
          }`}
        >
          {feedback.type === "SUCCESS" ? (
            <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
          ) : (
            <AlertCircle className="h-5 w-5 shrink-0 text-rose-600" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {/* FORM TAMBAH CICILAN BARU (CREATE) */}
      <section
        aria-label="Form Tambah Cicilan Baru"
        className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"
      >
        <div className="mb-3 flex items-center gap-2">
          <PlusCircle className="h-5 w-5 text-emerald-600" />
          <h2 className="text-sm font-extrabold text-slate-800">
            Tambah Pengingat Cicilan / Utang Baru
          </h2>
        </div>

        <form onSubmit={handleCreateBill} className="space-y-3.5">
          <div>
            <label
              htmlFor="bill-title"
              className="mb-1 block text-xs font-bold text-slate-600"
            >
              Nama Tagihan / Cicilan
            </label>
            <input
              id="bill-title"
              type="text"
              required
              placeholder="Contoh: Cicilan Motor / Kuota Bulanan / kontrakan"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 text-sm font-semibold text-slate-900 placeholder:font-normal placeholder:text-slate-400 focus:border-emerald-600 focus:bg-white focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="bill-amount"
                className="mb-1 block text-xs font-bold text-slate-600"
              >
                Nominal (Rp)
              </label>
              <input
                id="bill-amount"
                type="text"
                inputMode="numeric"
                required
                placeholder="Contoh: 150.000"
                value={
                  amountStr
                    ? parseInt(amountStr.replace(/\D/g, ""), 10).toLocaleString(
                        "id-ID"
                      )
                    : ""
                }
                onChange={(e) =>
                  setAmountStr(e.target.value.replace(/\D/g, ""))
                }
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-slate-50 px-3.5 text-sm font-semibold text-slate-900 placeholder:font-normal placeholder:text-slate-400 focus:border-emerald-600 focus:bg-white focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="bill-duedate"
                className="mb-1 block text-xs font-bold text-slate-600"
              >
                Jatuh Tempo
              </label>
              <input
                id="bill-duedate"
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-slate-50 px-3 text-sm font-semibold text-slate-900 focus:border-emerald-600 focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            id="btn-add-bill"
            disabled={isPending}
            className="flex min-h-[50px] w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-extrabold text-white shadow-md shadow-emerald-600/20 transition hover:bg-emerald-700 active:scale-[0.99] disabled:opacity-60"
          >
            <PlusCircle className="h-4 w-4" />
            <span>
              {isPending ? "Menyimpan..." : "Tambah ke Daftar Tagihan"}
            </span>
          </button>
        </form>
      </section>

      {/* DAFTAR UTANG & CICILAN (READ, UPDATE, DELETE, DAN BAYAR) */}
      <section aria-label="Daftar Tagihan dan Cicilan" className="space-y-3">
        <h2 className="px-1 text-sm font-extrabold text-slate-800">
          Daftar Cicilan & Tagihan ({initialBills.length})
        </h2>

        {initialBills.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-white py-10 px-4 text-center">
            <CreditCard className="h-10 w-10 text-slate-300" />
            <p className="mt-2 text-sm font-bold text-slate-600">
              Belum ada catatan utang atau cicilan
            </p>
            <p className="mt-1 max-w-xs text-xs text-slate-400">
              Tambahkan cicilan motor, kontrakan, atau tagihan rutin di form atas agar tidak terlewat tanggal jatuh temponya.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {initialBills.map((bill) => {
              const isEditingThis = editingId === bill.id;
              const formattedDueDate = new Date(
                bill.dueDate
              ).toLocaleDateString("id-ID", {
                day: "numeric",
                month: "long",
                year: "numeric",
              });

              return (
                <div
                  key={bill.id}
                  className={`rounded-3xl border p-4 shadow-sm transition-all ${
                    bill.isPaid
                      ? "border-slate-200 bg-slate-100/80"
                      : "border-slate-200 bg-white"
                  }`}
                >
                  {/* MODE EDIT (UPDATE): Mengubah Nama atau Nominal Cicilan */}
                  {isEditingThis ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700">
                          Edit Data Cicilan
                        </span>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>

                      <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-500">
                          Nama Cicilan
                        </label>
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          className="min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3 text-sm font-bold text-slate-900 focus:border-emerald-600 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="mb-1 block text-xs font-semibold text-slate-500">
                          Nominal (Rp)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={
                            editAmountStr
                              ? parseInt(
                                  editAmountStr.replace(/\D/g, ""),
                                  10
                                ).toLocaleString("id-ID")
                              : ""
                          }
                          onChange={(e) =>
                            setEditAmountStr(e.target.value.replace(/\D/g, ""))
                          }
                          className="min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3 text-sm font-bold text-slate-900 focus:border-emerald-600 focus:outline-none"
                        />
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          type="button"
                          disabled={isPending}
                          onClick={() => handleSaveEdit(bill.id)}
                          className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-4 text-xs font-extrabold text-white shadow-sm hover:bg-emerald-700 active:scale-95"
                        >
                          <Check className="h-4 w-4" />
                          <span>Simpan Perubahan</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="flex min-h-[44px] items-center justify-center rounded-xl border border-slate-300 bg-white px-4 text-xs font-bold text-slate-600 hover:bg-slate-50"
                        >
                          Batal
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* MODE TAMPILAN NORMAL */
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          {/* Badge Status Lunas vs Belum Lunas */}
                          <div className="mb-1.5 flex items-center gap-2">
                            {bill.isPaid ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-[11px] font-extrabold text-emerald-800">
                                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                                SUDAH LUNAS
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-[11px] font-extrabold text-amber-800">
                                <Clock className="h-3.5 w-3.5 text-amber-600" />
                                BELUM DIBAYAR
                              </span>
                            )}
                          </div>

                          <h3
                            className={`text-base font-extrabold ${
                              bill.isPaid
                                ? "line-through text-slate-500"
                                : "text-slate-900"
                            }`}
                          >
                            {bill.title}
                          </h3>

                          <p className="mt-0.5 flex items-center gap-1 text-xs font-medium text-slate-500">
                            <CalendarDays className="h-3.5 w-3.5 text-slate-400" />
                            <span>Jatuh Tempo: {formattedDueDate}</span>
                          </p>
                        </div>

                        {/* Nominal Tagihan */}
                        <div className="text-right">
                          <p
                            className={`text-lg font-black ${
                              bill.isPaid ? "text-slate-500" : "text-rose-600"
                            }`}
                          >
                            {formatRupiah(bill.amount)}
                          </p>
                        </div>
                      </div>

                      {/* Baris Tombol Aksi: Tombol "Bayar" (jika belum lunas), Tombol "Edit", dan Tombol "Delete" */}
                      <div className="mt-4 flex items-center justify-between gap-2 border-t border-slate-200/70 pt-3">
                        <div className="flex items-center gap-2">
                          {/* Opsi Edit Nama atau Nominal Cicilan */}
                          <button
                            type="button"
                            onClick={() => handleStartEdit(bill)}
                            disabled={isPending}
                            className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50 active:scale-95"
                          >
                            <Pencil className="h-3.5 w-3.5 text-slate-500" />
                            <span>Edit</span>
                          </button>

                          {/* Opsi Delete untuk menghapus cicilan secara permanen */}
                          <button
                            type="button"
                            onClick={() => handleDeleteBill(bill.id)}
                            disabled={isPending}
                            className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50/60 px-3 py-2 text-xs font-bold text-rose-700 transition hover:bg-rose-100 active:scale-95"
                          >
                            <Trash2 className="h-3.5 w-3.5 text-rose-600" />
                            <span>Hapus</span>
                          </button>
                        </div>

                        {/* Tombol Aksi "Bayar": Hanya aktif jika tagihan belum lunas (`!bill.isPaid`) */}
                        {!bill.isPaid ? (
                          <button
                            type="button"
                            id={`btn-pay-bill-${bill.id}`}
                            onClick={() => handlePayBill(bill.id)}
                            disabled={isPending}
                            className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-extrabold text-white shadow-sm shadow-emerald-600/20 transition hover:bg-emerald-700 active:scale-95 disabled:opacity-50"
                          >
                            <CreditCard className="h-4 w-4" />
                            <span>Bayar Sekarang</span>
                          </button>
                        ) : (
                          <span className="text-xs font-bold text-emerald-700">
                            Tercatat di Pengeluaran ✓
                          </span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
