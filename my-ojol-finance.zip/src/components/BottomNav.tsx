// File: src/components/BottomNav.tsx
// Tujuan: Komponen navigasi bawah (Bottom Navigation Bar) bergaya mobile-first yang tetap berada
// di bagian bawah layar ponsel (fixed bottom). Menghubungkan 3 rute utama:
// 1. "/"      -> Dashboard Keuangan
// 2. "/add"   -> Form Input Cepat (Tombol aksi utama yang menonjol)
// 3. "/bills" -> Modul Pengingat Utang & Tagihan

"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, PlusCircle, ReceiptText } from "lucide-react";

export default function BottomNav() {
  // Mengambil path rute saat ini untuk memberikan indikator warna aktif pada menu yang sedang dibuka
  const pathname = usePathname();

  // Sembunyikan navigasi bawah apabila pengguna sedang berada di halaman "/login"
  if (pathname.startsWith("/login")) {
    return null;
  }

  // Daftar item menu navigasi bawah beserta ikon dan labelnya
  const navItems = [
    {
      href: "/",
      label: "Beranda",
      icon: Home,
      isCenterAction: false,
    },
    {
      href: "/add",
      label: "Catat Cepat",
      icon: PlusCircle,
      isCenterAction: true, // Ditandai sebagai tombol utama di tengah agar mudah dijangkau ibu jari driver
    },
    {
      href: "/bills",
      label: "Tagihan",
      icon: ReceiptText,
      isCenterAction: false,
    },
  ];

  return (
    <nav
      aria-label="Navigasi Utama Mobile"
      className="fixed bottom-0 left-0 right-0 z-50 mx-auto max-w-md border-t border-slate-200 bg-white/95 backdrop-blur-md shadow-[0_-4px_20px_rgba(15,23,42,0.06)]"
    >
      <div className="grid grid-cols-3 items-center px-3 py-2">
        {navItems.map((item) => {
          // Menentukan apakah rute item ini sedang aktif dibuka oleh pengguna
          const isActive =
            item.href === "/"
              ? pathname === "/"
              : pathname.startsWith(item.href);

          const IconComponent = item.icon;

          // Render desain khusus untuk tombol tengah ("/add" - Catat Cepat) agar besar dan touch-friendly
          if (item.isCenterAction) {
            return (
              <Link
                key={item.href}
                href={item.href}
                id="nav-link-add"
                className="group flex flex-col items-center justify-center -mt-5 focus:outline-none"
              >
                <div
                  className={`flex h-14 w-14 items-center justify-center rounded-2xl shadow-lg transition-all duration-150 active:scale-95 ${
                    isActive
                      ? "bg-emerald-700 text-white ring-4 ring-emerald-100"
                      : "bg-emerald-600 text-white hover:bg-emerald-700"
                  }`}
                >
                  <IconComponent className="h-7 w-7 stroke-[2.2]" />
                </div>
                <span
                  className={`mt-1 text-xs font-bold tracking-tight ${
                    isActive ? "text-emerald-700" : "text-slate-600"
                  }`}
                >
                  {item.label}
                </span>
              </Link>
            );
          }

          // Render tombol navigasi reguler untuk Beranda (/) dan Tagihan (/bills)
          return (
            <Link
              key={item.href}
              href={item.href}
              id={`nav-link-${item.href === "/" ? "home" : "bills"}`}
              className={`flex min-h-[56px] flex-col items-center justify-center rounded-xl py-1.5 transition-colors active:bg-slate-100 ${
                isActive
                  ? "text-emerald-600 font-bold"
                  : "text-slate-500 font-medium hover:text-slate-800"
              }`}
            >
              <IconComponent
                className={`h-6 w-6 transition-transform ${
                  isActive ? "scale-110 stroke-[2.5]" : "stroke-[2]"
                }`}
              />
              <span className="mt-1 text-xs">{item.label}</span>
              {/* Indikator titik aktif di bawah teks menu */}
              {isActive && (
                <span className="mt-0.5 h-1 w-5 rounded-full bg-emerald-600" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
