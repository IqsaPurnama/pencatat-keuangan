// File: src/components/DashboardClient.tsx
// Tujuan: Komponen interaktif di halaman Dashboard untuk menangani:
// 1. Tombol Logout pengguna (NextAuth signOut)
// 2. Tombol Hapus Transaksi (memanggil Server Action deleteTransactionAction)

"use client";

import React, { useTransition } from "react";
import { signOut } from "next-auth/react";
import { deleteTransactionAction } from "@/actions/transaction-actions";
import { LogOut, Trash2 } from "lucide-react";

/**
 * Tombol Keluar (Logout) berukuran touch-friendly di bagian pojok kanan atas Header Dashboard
 */
export function LogoutButton() {
  return (
    <button
      type="button"
      id="btn-logout"
      onClick={() => signOut({ callbackUrl: "/login" })}
      title="Keluar Akun"
      className="flex min-h-[42px] items-center gap-1.5 rounded-xl bg-white/15 px-3.5 py-2 text-xs font-bold text-white backdrop-blur-sm transition hover:bg-white/25 active:scale-95"
    >
      <LogOut className="h-4 w-4" />
      <span>Keluar</span>
    </button>
  );
}

/**
 * Tombol Hapus satu item riwayat transaksi di Dashboard menggunakan Server Action
 */
export function DeleteTransactionButton({ id }: { id: string }) {
  const [isPending, startTransition] = useTransition();

  const handleDelete = () => {
    startTransition(async () => {
      await deleteTransactionAction(id);
    });
  };

  return (
    <button
      type="button"
      onClick={handleDelete}
      disabled={isPending}
      aria-label="Hapus transaksi"
      title="Hapus transaksi ini"
      className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-600 active:scale-95 disabled:opacity-40"
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
}
