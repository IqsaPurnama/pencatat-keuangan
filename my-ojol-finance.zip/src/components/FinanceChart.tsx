// File: src/components/FinanceChart.tsx
// Tujuan: Menampilkan grafik batang ganda (Bar Chart) interaktif untuk membandingkan
// tren Pendapatan Kotor (Hijau) vs Pengeluaran Operasional (Merah) berdasarkan filter waktu.
// Dibuat menggunakan SVG murni & Tailwind CSS agar ringan di ponsel dan tanpa ketergantungan library berat.

"use client";

import React from "react";
import { ChartDataPoint } from "@/actions/transaction-actions";
import { BarChart3 } from "lucide-react";

interface FinanceChartProps {
  data: ChartDataPoint[];
  filterLabel: string;
}

/**
 * Fungsi pembantu untuk menyingkat angka rupiah besar pada label grafik
 * Contoh: 150000 -> "150rb", 1200000 -> "1.2jt"
 */
function formatCompactRupiah(value: number): string {
  if (value === 0) return "0";
  if (value >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(1).replace(/\.0$/, "")}jt`;
  }
  if (value >= 1_000) {
    return `${Math.round(value / 1_000)}rb`;
  }
  return `${value}`;
}

export default function FinanceChart({ data, filterLabel }: FinanceChartProps) {
  // 1. Mencari nilai tertinggi (maksimum) dari seluruh titik data (baik income maupun expense)
  // untuk menentukan skala persentase tinggi batang grafik (0% - 100%).
  const maxVal = Math.max(
    ...data.map((d) => Math.max(d.income, d.expense)),
    50_000 // Nilai dasar minimal Rp 50.000 agar grafik tidak rata saat semua nilai masih 0
  );

  return (
    <section
      aria-label="Grafik Tren Keuangan"
      className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
    >
      {/* Header Grafik & Legenda Warna */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
            <BarChart3 className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-800">
              Grafik Tren Keuangan
            </h2>
            <p className="text-xs text-slate-500">Periode: {filterLabel}</p>
          </div>
        </div>

        {/* Legenda Indikator Batang Hijau (Pendapatan) & Merah (Pengeluaran) */}
        <div className="flex items-center gap-3 text-xs font-medium">
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-emerald-500" />
            <span className="text-slate-600">Masuk</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-sm bg-rose-500" />
            <span className="text-slate-600">Keluar</span>
          </div>
        </div>
      </div>

      {/* Area Visualisasi Batang (Bar Chart) */}
      <div className="relative pt-4">
        {/* Garis bantu horizontal tipis di latar belakang */}
        <div className="pointer-events-none absolute inset-x-0 top-4 bottom-8 flex flex-col justify-between">
          <div className="border-b border-dashed border-slate-100" />
          <div className="border-b border-dashed border-slate-100" />
          <div className="border-b border-dashed border-slate-100" />
        </div>

        <div
          className="relative z-10 grid items-end gap-2 pt-2"
          style={{
            gridTemplateColumns: `repeat(${data.length}, minmax(0, 1fr))`,
          }}
        >
          {data.map((point, index) => {
            // Menghitung persentase tinggi batang relatif terhadap nilai tertinggi (maxVal)
            const incomeHeightPercent = Math.round((point.income / maxVal) * 100);
            const expenseHeightPercent = Math.round((point.expense / maxVal) * 100);

            return (
              <div
                key={index}
                className="flex flex-col items-center justify-end"
              >
                {/* Kontainer pasangan batang Pendapatan & Pengeluaran dengan tinggi tetap 136px */}
                <div className="flex h-36 w-full items-end justify-center gap-1 px-0.5">
                  {/* Batang Pendapatan (Hijau) */}
                  <div className="flex h-full flex-1 max-w-[22px] flex-col items-center justify-end">
                    {point.income > 0 && (
                      <span className="mb-1 text-[10px] font-bold text-emerald-700 leading-none">
                        {formatCompactRupiah(point.income)}
                      </span>
                    )}
                    <div
                      style={{
                        height: `${
                          point.income > 0 ? Math.max(incomeHeightPercent, 8) : 3
                        }%`,
                      }}
                      title={`Pendapatan ${point.label}: Rp ${point.income.toLocaleString("id-ID")}`}
                      className={`w-full rounded-t-md transition-all duration-300 ${
                        point.income > 0
                          ? "bg-emerald-500 shadow-sm"
                          : "bg-slate-100"
                      }`}
                    />
                  </div>

                  {/* Batang Pengeluaran (Merah) */}
                  <div className="flex h-full flex-1 max-w-[22px] flex-col items-center justify-end">
                    {point.expense > 0 && (
                      <span className="mb-1 text-[10px] font-bold text-rose-600 leading-none">
                        {formatCompactRupiah(point.expense)}
                      </span>
                    )}
                    <div
                      style={{
                        height: `${
                          point.expense > 0 ? Math.max(expenseHeightPercent, 8) : 3
                        }%`,
                      }}
                      title={`Pengeluaran ${point.label}: Rp ${point.expense.toLocaleString("id-ID")}`}
                      className={`w-full rounded-t-md transition-all duration-300 ${
                        point.expense > 0
                          ? "bg-rose-500 shadow-sm"
                          : "bg-slate-100"
                      }`}
                    />
                  </div>
                </div>

                {/* Label Sumbu X (Waktu: Jam / Hari / Minggu) */}
                <span className="mt-2 w-full truncate text-center text-[11px] font-semibold text-slate-600">
                  {point.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
