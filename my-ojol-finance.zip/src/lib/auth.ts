// File: src/lib/auth.ts
// Tujuan: Konfigurasi lengkap NextAuth.js menggunakan Credentials Provider (Username & Password).
// File ini dipisahkan agar objek `authOptions` bisa diimpor oleh API Route maupun Server Components / Server Actions.

import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";

// Memperluas tipe bawaan NextAuth agar properti `id` dan `username` dikenali di dalam Session dan JWT
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      username: string;
      name?: string | null;
    };
  }
  interface User {
    id: string;
    username: string;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    username: string;
  }
}

export const authOptions: NextAuthOptions = {
  // Menggunakan strategi berbasis JSON Web Token (JWT) agar kompatibel penuh dengan Next.js Middleware
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // Sesi berlaku selama 30 hari agar driver ojol tidak perlu login berulang kali setiap hari
  },
  // Mendefinisikan halaman kustom untuk proses autentikasi
  pages: {
    signIn: "/login", // Mengarahkan pengguna yang belum login ke halaman /login
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      // Mendefinisikan kolom input yang diterima dari form login
      credentials: {
        username: { label: "Username", type: "text", placeholder: "bang_ojol" },
        password: { label: "Password", type: "password" },
      },
      // Fungsi utama untuk memvalidasi kredensial pengguna ke database Prisma
      async authorize(credentials) {
        // 1. Validasi awal: pastikan input username dan password tidak kosong
        if (!credentials?.username || !credentials?.password) {
          throw new Error("Username dan password wajib diisi!");
        }

        // 2. Bersihkan spasi berlebih pada username dan ubah ke huruf kecil agar konsisten
        const cleanUsername = credentials.username.trim();

        // 3. Cari data pengguna di tabel User berdasarkan username menggunakan Prisma
        const user = await prisma.user.findUnique({
          where: {
            username: cleanUsername,
          },
        });

        // 4. Jika pengguna tidak ditemukan di database, tolak proses login
        if (!user) {
          throw new Error("Akun tidak ditemukan. Silakan periksa kembali username Anda.");
        }

        // 5. Bandingkan password teks biasa dari input dengan password ter-hash (bcrypt) di database
        const isPasswordValid = await bcrypt.compare(credentials.password, user.password);

        // 6. Jika password tidak cocok, hentikan proses dan kirim pesan error
        if (!isPasswordValid) {
          throw new Error("Password yang Anda masukkan salah.");
        }

        // 7. Jika validasi berhasil, kembalikan objek user yang akan disimpan ke dalam token JWT
        return {
          id: user.id,
          username: user.username,
          name: user.username,
        };
      },
    }),
  ],
  callbacks: {
    // Callback JWT: dipanggil setiap kali token JWT dibuat atau diperbarui
    async jwt({ token, user }) {
      // Saat pertama kali login, objek `user` tersedia; salin `id` dan `username` ke dalam token
      if (user) {
        token.id = user.id;
        token.username = user.username;
      }
      return token;
    },
    // Callback Session: dipanggil setiap kali komponen atau Server Action mengecek sesi aktif (`getServerSession`)
    async session({ session, token }) {
      // Menyalin `id` dan `username` dari token JWT ke dalam objek `session.user` agar bisa dipakai di query Prisma
      if (token && session.user) {
        session.user.id = token.id;
        session.user.username = token.username;
      }
      return session;
    },
  },
  // Kunci rahasia untuk mengenkripsi token sesi NextAuth
  secret: process.env.NEXTAUTH_SECRET,
};
