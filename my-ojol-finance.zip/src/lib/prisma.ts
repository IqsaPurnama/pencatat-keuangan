// File: src/lib/prisma.ts
// Tujuan: Menginisialisasi instance tunggal (Singleton) dari PrismaClient.
// Pola ini wajib digunakan di Next.js agar saat proses Hot-Reloading (Development)
// aplikasi tidak terus-menerus membuat koneksi database baru yang menyebabkan error "Too many connections".

import { PrismaClient } from "@prisma/client";

// Mendeklarasikan variabel global untuk menyimpan instance PrismaClient di memori Node.js
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

// Jika instance sudah ada di globalThis, gunakan kembali instance tersebut.
// Jika belum ada, buat instance PrismaClient baru dengan logging query untuk memudahkan debugging.
export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
  });

// Di lingkungan selain production (misal: development), simpan instance ke objek globalThis
if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}

export default prisma;
