// File: src/middleware.ts
// Tujuan: Mengunci seluruh halaman aplikasi agar hanya bisa diakses oleh pengguna (driver ojol) yang sudah login.
// Jika pengguna belum login dan mencoba mengakses /, /add, atau /bills, mereka akan otomatis diarahkan ke /login.
// Sebaliknya, jika pengguna sudah login dan membuka halaman /login, mereka akan langsung diarahkan ke Dashboard (/).

import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getToken } from "next-auth/jwt";

export async function middleware(request: NextRequest) {
  // 1. Mengambil token JWT dari cookies request menggunakan secret NextAuth
  const token = await getToken({
    req: request,
    secret: process.env.NEXTAUTH_SECRET,
  });

  // 2. Mengambil path URL yang sedang diakses oleh pengguna
  const { pathname } = request.nextUrl;

  // 3. Mengecek apakah pengguna sedang mengakses halaman login
  const isLoginPage = pathname.startsWith("/login");

  // 4. Jika pengguna SUDAH login (token ada) tetapi membuka halaman /login,
  // arahkan langsung ke halaman utama Dashboard (/) agar tidak perlu login dua kali.
  if (isLoginPage && token) {
    return NextResponse.redirect(new URL("/", request.url));
  }

  // 5. Jika pengguna BELUM login (token kosong) dan mencoba mengakses halaman yang dilindungi (bukan /login),
  // paksa redirect ke halaman /login untuk menjaga keamanan data keuangan pengguna.
  if (!isLoginPage && !token) {
    const loginUrl = new URL("/login", request.url);
    return NextResponse.redirect(loginUrl);
  }

  // 6. Jika kondisi aman, izinkan request dilanjutkan ke halaman tujuan
  return NextResponse.next();
}

// Konfigurasi Matcher: menentukan rute mana saja yang akan diperiksa oleh Middleware ini.
// Mengecualikan rute internal Next.js (_next/static, _next/image), endpoint API auth (/api/auth), dan file ikon statis.
export const config = {
  matcher: ["/((?!api/auth|_next/static|_next/image|favicon.ico).*)"],
};
